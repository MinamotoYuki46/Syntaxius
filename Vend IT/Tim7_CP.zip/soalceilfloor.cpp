#include <iostream>
#include <cmath>

using namespace std;

int main(){
    double n, m, o;
    
    cin >> n;
    cout << floor(n) << " " << ceill(n) << endl;

}
